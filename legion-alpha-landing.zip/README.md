# Legion Alpha Landing Page

Next.js + TailwindCSS landing page for Legion Alpha - the AI-native tactical trading platform.
