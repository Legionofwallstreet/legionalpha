
import Head from 'next/head'
import Hero from '../components/Hero'
import Features from '../components/Features'
import Tiers from '../components/Tiers'
import Waitlist from '../components/Waitlist'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <div>
      <Head>
        <title>Legion Alpha</title>
        <meta name="description" content="AI-native tactical trading platform" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <Hero />
      <Features />
      <Tiers />
      <Waitlist />
      <Footer />
    </div>
  )
}
