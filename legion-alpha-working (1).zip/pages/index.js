
import Head from 'next/head'

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4">
      <Head>
        <title>Legion Alpha</title>
        <meta name="description" content="Smarter Trades. Machine Precision. Human Vision." />
      </Head>
      <h1 className="text-5xl font-bold text-center mb-6">Legion Alpha</h1>
      <p className="text-xl text-center mb-8">Smarter Trades. Machine Precision. Human Vision.</p>
      <a href="#" className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
        Join the Legion
      </a>
    </div>
  )
}
