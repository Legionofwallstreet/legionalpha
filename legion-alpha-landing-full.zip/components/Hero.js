
export default function Hero() {
  return (
    <section className="text-center py-20 bg-black text-white">
      <h1 className="text-5xl font-extrabold mb-4">Smarter Trades. Machine Precision. Human Vision.</h1>
      <p className="text-lg mb-6">AI-native trading platform for equities, crypto, and options.</p>
      <a href="#waitlist" className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded">
        Join the Legion
      </a>
    </section>
  );
}
