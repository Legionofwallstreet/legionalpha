
export default function Tiers() {
  return (
    <section className="bg-black text-white py-16 px-4">
      <h2 className="text-3xl font-bold text-center mb-10">Product Tiers</h2>
      <div className="grid md:grid-cols-3 gap-8">
        <div className="border border-red-600 p-6 rounded">
          <h3 className="text-xl font-semibold mb-2">Legion Scout</h3>
          <p>Free tier: Market briefs, earnings alerts, watchlists.</p>
        </div>
        <div className="border border-red-600 p-6 rounded">
          <h3 className="text-xl font-semibold mb-2">Legion Operative</h3>
          <p>Pro tier: Live signals, sniper entries, SL/TP logic.</p>
        </div>
        <div className="border border-red-600 p-6 rounded">
          <h3 className="text-xl font-semibold mb-2">Legion Ghost</h3>
          <p>Elite tier: Fully autonomous AI trading agents.</p>
        </div>
      </div>
    </section>
  );
}
