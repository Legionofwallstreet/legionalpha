
export default function Waitlist() {
  return (
    <section id="waitlist" className="bg-gray-800 text-white py-16 px-4">
      <h2 className="text-3xl font-bold text-center mb-8">Join the Waitlist</h2>
      <form action="https://formsubmit.co/YOUR_EMAIL" method="POST" className="max-w-md mx-auto">
        <input
          type="email"
          name="email"
          required
          placeholder="Enter your email"
          className="w-full p-3 mb-4 rounded bg-gray-900 border border-gray-700"
        />
        <button
          type="submit"
          className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
        >
          Secure Early Access
        </button>
      </form>
    </section>
  );
}
