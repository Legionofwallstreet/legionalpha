
export default function Features() {
  return (
    <section className="bg-gray-900 text-white py-16 px-4">
      <h2 className="text-3xl font-bold text-center mb-10">Key Features</h2>
      <div className="grid md:grid-cols-3 gap-8">
        <div>
          <h3 className="text-xl font-semibold mb-2">Adaptive AI Signal Engine</h3>
          <p>Continuously learns and evolves across all market regimes.</p>
        </div>
        <div>
          <h3 className="text-xl font-semibold mb-2">Agent-Based Bot Control</h3>
          <p>Execute sniper entries, SL/TP, and full trade lifecycle management.</p>
        </div>
        <div>
          <h3 className="text-xl font-semibold mb-2">Multi-Asset Ready</h3>
          <p>Equities, crypto, options — ready out of the box.</p>
        </div>
      </div>
    </section>
  );
}
